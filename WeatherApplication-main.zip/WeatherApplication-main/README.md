# WeatherApplication
A simple weather application using the openweather API.

STEPS TO RUN THE CODE: 
1. Go to https://openweathermap.org
2. Create a free account
3. Navigate to the API keys section
4. Generate a key
5. Copy that key to clipboard
6. Insert that key into the required variable in the script.js file
7. Enjoy!
